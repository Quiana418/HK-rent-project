<template>
  <div>注册1111</div>
</template>

<script>
export default {
  name: 'Register',
  created () { },
  data () {
    return {}
  },
  methods: {},
  computed: {},
  watch: {},
  filters: {},
  components: {}
}
</script>

<style scoped lang='less'>
</style>
